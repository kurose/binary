$(function() {
    //Replace from '。' and '.' to '~(=^･ω･^)ﾉ☆ '.
    var nya = '~(=^･ω･^)ﾉ☆ ';
    var body = $('body');
    
    chrome.storage.local.get(       
        {state: false},        
        function(data) {
            if(data.state) {
                //「。」か「'.'と空白」か「'.'と'<'（HTMLの開始タグ）」であれば置換
                body.html(body.html().replace(/。/g, nya).replace(/\.\s/g, nya).replace(/\.</g, nya + '<'));
            }
        }
    );
    
    //イベントリスナーをセット
    chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
        if (request == "Action") {
            //現在の設定値を取り出す
            chrome.storage.local.get(
                {state: false},
                function(data) {
                    if(data.state) {
                        alert('Change Nya! to invalid. \nNya!を無効にします');
                    } else {
                        alert('Change Nya! to valid. \nNya!を有効にします。')
                    }
                    //反転して保存＆リロード
                    chrome.storage.local.set({state: !data.state}, function(){ location.reload(); });
                }
            );
        }
    });
});